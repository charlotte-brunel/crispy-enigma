void trier(int* v, int g, int d);
void separer(int* v, int g, int d, int* indice_pivot);
